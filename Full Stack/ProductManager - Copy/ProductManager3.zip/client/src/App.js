import './App.css';
import React from 'react';
import Main from './views/main';
import Detail from './views/detail';
import Update from './views/update';
import { Router } from '@reach/router';

function App() {
  return (
    <div className="App">
      <Router>
        <Main path = "/" />
        <Detail path = "products/:id" />
        <Update path = "products/update/:id" />
      </Router>
    </div>
  );
}

export default App;
