import React, { useState } from 'react'
import axios from 'axios';

export default() => {
const [title, setTitle] = useState("")
const [price, setPrice] = useState("");
const [description, setDescription] = useState("");

const submitHandler = (e) => {

    axios.post('http://localhost:8000/api/products/new', {
        title,
        price,
        description
    })
        .then(res=>console.log(res))
        .catch(err=>console.log(err))
}

    return (
        <div>
            
            <form onSubmit = {submitHandler}>
                <label>Title</label>
                <input type="text" onChange={e => setTitle(e.target.value)}/><br/>

                <label>Price</label>
                <input type="text" onChange={e => setPrice(e.target.value)}/><br/>

                <label>Description</label>
                <input type="text" onChange={e => setDescription(e.target.value)}/><br/><br/>
            
                <input type="submit" value="Create" className = "btn btn-outline-primary btn-sm"/>
            </form>         
            
        </div>
    )
}