import './App.css';
import BoxForm from './components/BoxForm';



function App() {



  return (
    <div className="App">
      <BoxForm />
    </div>
  );
}

export default App;
