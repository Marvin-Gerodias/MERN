import React from 'react';

// import { Link } from '@reach/router';

const HomeComponent = props => {
    return (
        <h2>Welcome Home!</h2>
    );
}

export default HomeComponent;